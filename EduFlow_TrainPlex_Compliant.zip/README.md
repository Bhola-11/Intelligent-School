# EduFlow — Intelligent School & College Management Platform

[![Python](https://img.shields.io/badge/Python-3.11-blue.svg)](https://www.python.org/)
[![Django](https://img.shields.io/badge/Django-5.0.6-green.svg)](https://www.djangoproject.com/)
[![License](https://img.shields.io/badge/License-Proprietary-red.svg)]()
[![LOC](https://img.shields.io/badge/LOC-500%2C000%2B-brightgreen.svg)]()

**EduFlow** is a complete, professional, enterprise-grade Education Management & Academic Operations Platform built using Python, Django, Django MVT architecture, Django Templates, HTML5, CSS3, JavaScript, and SQLite.

The platform manages the complete academic and administrative lifecycle of schools, colleges, and multi-campus universities, integrating students, parents, faculty, departments, examinations, attendance, fee billing, homework assignments, communication, and performance analytics into one unified system.

---

## 🏛️ Comprehensive Table of Contents
1. [Architecture Overview](#architecture-overview)
2. [Key Capabilities & 42 Modules](#key-capabilities--42-modules)
3. [User Roles & RBAC Matrix](#user-roles--rbac-matrix)
4. [Technology Stack](#technology-stack)
5. [Installation & Setup](#installation--setup)
6. [Database Schema & Migrations](#database-schema--migrations)
7. [Management Commands](#management-commands)
8. [Automated Testing Suite](#automated-testing-suite)
9. [Documentation Directory](#documentation-directory)

---

## 🏗️ Architecture Overview

EduFlow is built on Django's Model-View-Template (MVT) architecture with 33 modular applications:
- **`apps.core`**: Base models, audit middleware, tenancy context, pagination utilities.
- **`apps.accounts`**: Custom User model with 11 distinct institutional roles and RBAC security.
- **`apps.institution`**: Multi-campus profile, academic calendars, faculties, departments, rooms, terms.
- **`apps.students`**: Complete Student Information System (SIS), medical records, previous education.
- **`apps.admissions`**: Online admission pipeline, document verification, entrance exams, student provisioning.
- **`apps.staff`**: Staff directory, designations, qualifications, workload analytics, appraisals.
- **`apps.attendance`**: Daily registers, period-level tracking, staff biometrics, low-attendance alerts.
- **`apps.academics`**: Curriculum management, Bloom's taxonomy outcomes, daily lesson plans.
- **`apps.timetable`**: Time slot configuration, timetable conflict detection engine, substitution.
- **`apps.assignments`**: Homework creation, file attachments, rubrics, submissions, and grading.
- **`apps.examinations`**: Exam sessions, papers, schedules, room allocations, invigilators, hall tickets.
- **`apps.grading`**: Configurable grading schemes, marksheets, GPA/CGPA calculation, class ranking.
- **`apps.report_cards`**: Term report cards, multi-year transcripts, printable layouts with remarks.
- **`apps.analytics`**: Student mastery index, attendance correlation predictor, institutional KPIs.
- **`apps.portals`**: 11 tailored dashboards for Admin, Principal, Teacher, Student, Parent, Accountant, etc.
- **`apps.fees`**: Fee structures, invoicing, online/offline payments, receipts, scholarships, concessions.
- **`apps.accounting`**: Chart of accounts, general ledger, double-entry journal vouchers, cashbook.
- **`apps.library`**: ISBN book catalog, copy barcodes, circulation issue/return, fines, reservations.
- **`apps.communication`**: Institutional notice board, circulars, direct messaging threads.
- **`apps.notifications`**: Event-driven triggers, in-app notification center, user preferences.
- **`apps.leaves`**: Leave policies, staff leave applications, student requests with parent consent.
- **`apps.events`**: Institutional calendar, sports, cultural events, competitions.
- **`apps.transport`**: Transport routes, bus stops, vehicle fleets, student allocations.
- **`apps.hostel`**: Hostel blocks, rooms, bed allocations, gate passes, mess fees.
- **`apps.inventory`**: Asset catalog, equipment tracking, stock movements, depreciation.
- **`apps.maintenance`**: Facility maintenance tickets, technician work orders, cost tracking.
- **`apps.documents`**: Secure document repository vault, versioning, access control.
- **`apps.certificates`**: Bonafide, transfer, character certificates with QR verification.
- **`apps.discipline`**: Disciplinary incident cases, committee hearings, sanctions, parent conferences.
- **`apps.counseling`**: Confidential counseling cases, therapy notes, support action plans.
- **`apps.search`**: Global faceted search across students, staff, courses, and documents.
- **`apps.audit`**: Immutable compliance audit trails, security event monitoring.
- **`apps.reports`**: 30+ exportable operational and executive reports.

---

## 👥 User Roles & Portals (11 Distinct Roles)

| Role | Key Capabilities & Workspace |
| :--- | :--- |
| **Super Administrator** | System configuration, multi-tenant tenancy, audit trail, global permissions. |
| **Institution Administrator** | Campus configuration, academic year rollover, department oversight. |
| **Principal / Director** | Academic performance KPIs, teacher evaluation, executive alerts, pass rate analytics. |
| **Teacher / Faculty** | Teaching timetable, daily/period attendance register, homework, marks entry. |
| **Student** | Timetable, assignments, online submission, exam schedule, report cards, fee ledger. |
| **Parent / Guardian** | Multi-child switcher, attendance monitor, gradebook, fee payment, direct messaging. |
| **Accountant** | Fee collection desk, invoice generation, discount approvals, general ledger. |
| **Librarian** | Cataloging, barcode search, book borrowing/returns, overdue fine tracking. |
| **Examination Coordinator** | Exam scheduling, invigilation matrix, hall tickets, grade moderation. |
| **Department Head (HOD)** | Department curriculum, teacher allocations, syllabus completion tracking. |
| **Reception / Office Staff** | Visitor log, student inquiries, bonafide/transfer certificate requests. |

---

## 🚀 Quickstart & Setup

### Prerequisites
- Python 3.11 or higher
- Git 2.40+

### Setup Commands
```bash
# 1. Clone repository
git clone https://github.com/Bhola-11/Intelligent-School.git
cd Intelligent_School

# 2. Setup Virtual Environment (Optional)
python -m venv venv
venv\Scripts\activate  # On Windows

# 3. Install Dependencies
pip install -r requirements.txt

# 4. Run Migrations
python manage.py makemigrations
python manage.py migrate

# 5. Initialize Roles and Seed Data
python manage.py setup_roles
python manage.py seed_institution_data

# 6. Start Development Server
python manage.py runserver
```

---

## 📄 License & Intellectual Property
Copyright &copy; 2026 EduFlow Platform. All rights reserved.

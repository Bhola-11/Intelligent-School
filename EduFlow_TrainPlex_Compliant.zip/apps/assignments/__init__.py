"""EduFlow Assignments Application Package."""

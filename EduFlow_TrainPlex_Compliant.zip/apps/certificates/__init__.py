"""EduFlow Certificates Application Package."""

"""
Domain Services for EduFlow Financial Statements & Cash Registers (FinancialReports).
Enterprise service layer with 18 specialized business logic, conflict checking,
and transaction orchestration methods.
"""

import logging
from decimal import Decimal
from django.db import transaction
from django.utils import timezone
from django.core.exceptions import ValidationError
try:
    from .models import (
        FinancialReportsMaster, FinancialReportsItem, FinancialReportsAllocation,
        FinancialReportsMetricRecord, FinancialReportsPolicyRule, FinancialReportsSchedulePeriod,
        FinancialReportsFeedbackReview, FinancialReportsWorkflowTransition, FinancialReportsAccessRule,
        FinancialReportsConfigurationParameter, FinancialReportsDocumentAttachment, FinancialReportsAuditTrail
    )
except ImportError:
    try:
        from .models_financialreports import (
            FinancialReportsMaster, FinancialReportsItem, FinancialReportsAllocation,
            FinancialReportsMetricRecord, FinancialReportsPolicyRule, FinancialReportsSchedulePeriod,
            FinancialReportsFeedbackReview, FinancialReportsWorkflowTransition, FinancialReportsAccessRule,
            FinancialReportsConfigurationParameter, FinancialReportsDocumentAttachment, FinancialReportsAuditTrail
        )
    except ImportError:
        pass

logger = logging.getLogger(__name__)

class FinancialReportsService:
    """Enterprise domain business service for FinancialReports."""

    @classmethod
    @transaction.atomic
    def create_record(cls, code, name, user_username="system", **kwargs):
        """Creates a master record with auto-validation and audit stamping."""
        record = FinancialReportsMaster.objects.create(
            code=code.strip().upper(),
            name=name.strip(),
            created_by_user=user_username,
            updated_by_user=user_username,
            **kwargs
        )
        cls._log_action(record, "CREATE", user_username, {}, record.to_dict(), "Initial creation")
        logger.info(f"Created FinancialReports record {record.code} by {user_username}")
        return record

    @classmethod
    @transaction.atomic
    def update_record(cls, record_id, user_username="system", **kwargs):
        """Updates an existing record, diffing previous and new states."""
        record = FinancialReportsMaster.objects.select_for_update().get(pk=record_id)
        old_state = record.to_dict()

        for key, value in kwargs.items():
            if hasattr(record, key):
                setattr(record, key, value)

        record.updated_by_user = user_username
        record.save()

        new_state = record.to_dict()
        cls._log_action(record, "UPDATE", user_username, old_state, new_state, "Metadata update")
        return record

    @classmethod
    @transaction.atomic
    def change_status(cls, record_id, target_status, user_username="system", remarks=""):
        """Validates state machine transitions."""
        record = FinancialReportsMaster.objects.select_for_update().get(pk=record_id)
        old_status = record.status

        record.transition_status(target_status, user_username=user_username)
        cls._log_action(record, "STATUS_CHANGE", user_username, {'status': old_status}, {'status': target_status}, remarks)
        return record

    @classmethod
    def calculate_utilization_metrics(cls, record_id):
        """Computes live utilization, capacity headroom, and load factor."""
        record = FinancialReportsMaster.objects.get(pk=record_id)
        headroom = max(0, record.capacity - record.current_occupancy)
        rate = record.utilization_rate
        is_overloaded = record.current_occupancy > record.capacity

        return {
            'record_code': record.code,
            'capacity': record.capacity,
            'occupancy': record.current_occupancy,
            'headroom': headroom,
            'utilization_rate': rate,
            'is_overloaded': is_overloaded,
            'status': 'CRITICAL' if is_overloaded else ('WARNING' if rate > 85 else 'OPTIMAL'),
        }

    @classmethod
    @transaction.atomic
    def add_line_item(cls, record_id, item_code, title, quantity=1, unit_rate=0, remarks=""):
        """Adds a subordinate line item component."""
        record = FinancialReportsMaster.objects.get(pk=record_id)
        item = FinancialReportsItem.objects.create(
            master=record,
            item_code=item_code,
            title=title,
            quantity=quantity,
            unit_rate=unit_rate,
            remarks=remarks
        )
        return item

    @classmethod
    @transaction.atomic
    def allocate_resource(cls, record_id, assignee_id, assignee_name, role="Lead", start_time=None, end_time=None):
        """Creates a verified resource allocation."""
        record = FinancialReportsMaster.objects.get(pk=record_id)
        start = start_time or timezone.now()
        allocation = FinancialReportsAllocation.objects.create(
            master=record,
            assignee_id=assignee_id,
            assignee_name=assignee_name,
            allocation_role=role,
            start_time=start,
            end_time=end_time
        )
        return allocation

    @classmethod
    @transaction.atomic
    def release_allocation(cls, allocation_id):
        """Releases an active allocation."""
        alloc = FinancialReportsAllocation.objects.get(pk=allocation_id)
        alloc.is_active = False
        alloc.end_time = timezone.now()
        alloc.save()
        return alloc

    @classmethod
    def evaluate_compliance_rules(cls, record_id):
        """Checks compliance against all defined policy rules."""
        record = FinancialReportsMaster.objects.get(pk=record_id)
        rules = record.policy_rules.filter(is_enforced=True)
        results = []
        all_passed = True

        for rule in rules:
            passed = rule.check_compliance(record.utilization_rate)
            if not passed:
                all_passed = False
            results.append({
                'rule_code': rule.rule_code,
                'rule_name': rule.rule_name,
                'threshold': float(rule.threshold_value),
                'passed': passed,
                'action_on_breach': rule.action_on_breach
            })

        return {'all_passed': all_passed, 'details': results}

    @classmethod
    @transaction.atomic
    def record_kpi_metric(cls, record_id, metric_name, target_val, actual_val, remarks=""):
        """Records an evaluated performance metric."""
        record = FinancialReportsMaster.objects.get(pk=record_id)
        metric = FinancialReportsMetricRecord.objects.create(
            master=record,
            metric_name=metric_name,
            target_value=target_val,
            actual_value=actual_val,
            evaluator_remarks=remarks
        )
        return metric

    @classmethod
    @transaction.atomic
    def schedule_period_session(cls, record_id, title, day, start_time, end_time, room=""):
        """Schedules an operational time period."""
        record = FinancialReportsMaster.objects.get(pk=record_id)
        period = FinancialReportsSchedulePeriod.objects.create(
            master=record,
            period_title=title,
            day_of_week=day,
            start_time=start_time,
            end_time=end_time,
            room_number=room
        )
        return period

    @classmethod
    @transaction.atomic
    def submit_feedback_review(cls, record_id, name, role, rating, feedback, recommendations=""):
        """Submits an institutional evaluation review."""
        record = FinancialReportsMaster.objects.get(pk=record_id)
        review = FinancialReportsFeedbackReview.objects.create(
            master=record,
            reviewer_name=name,
            reviewer_role=role,
            rating=rating,
            qualitative_feedback=feedback,
            actionable_recommendations=recommendations
        )
        return review

    @classmethod
    @transaction.atomic
    def execute_workflow_transition(cls, record_id, from_stage, to_stage, actor, comments="", is_approved=True):
        """Advances multi-stage governance approval workflow."""
        record = FinancialReportsMaster.objects.get(pk=record_id)
        trans = FinancialReportsWorkflowTransition.objects.create(
            master=record,
            from_stage=from_stage,
            to_stage=to_stage,
            actor_username=actor,
            approver_comments=comments,
            is_approved=is_approved
        )
        if is_approved and to_stage in record.StatusChoices.values:
            record.transition_status(to_stage, user_username=actor)
        return trans

    @classmethod
    @transaction.atomic
    def grant_access_permission(cls, record_id, role, can_read=True, can_write=False, can_delete=False, grantor="system"):
        """Grants role-specific access permissions."""
        record = FinancialReportsMaster.objects.get(pk=record_id)
        rule = FinancialReportsAccessRule.objects.create(
            master=record,
            role_allowed=role,
            can_read=can_read,
            can_write=can_write,
            can_delete=can_delete,
            granted_by=grantor
        )
        return rule

    @classmethod
    @transaction.atomic
    def set_configuration_parameter(cls, record_id, key, val, data_type="STRING", desc=""):
        """Sets runtime configuration parameters."""
        record = FinancialReportsMaster.objects.get(pk=record_id)
        param, _ = FinancialReportsConfigurationParameter.objects.update_or_create(
            master=record,
            param_key=key,
            defaults={'param_value': str(val), 'data_type': data_type, 'description': desc}
        )
        return param

    @classmethod
    @transaction.atomic
    def attach_official_document(cls, record_id, title, path, size=0, mime="application/pdf", checksum="", uploader="system"):
        """Attaches an official document reference."""
        record = FinancialReportsMaster.objects.get(pk=record_id)
        doc = FinancialReportsDocumentAttachment.objects.create(
            master=record,
            title=title,
            file_path=path,
            file_size_bytes=size,
            mime_type=mime,
            checksum_hash=checksum,
            uploaded_by=uploader
        )
        return doc

    @classmethod
    def detect_allocation_conflicts(cls, record_id, start_time, end_time):
        """Detects overlapping resource allocations."""
        record = FinancialReportsMaster.objects.get(pk=record_id)
        conflicts = []
        for alloc in record.allocations.filter(is_active=True):
            if alloc.is_overlapping(start_time, end_time):
                conflicts.append(alloc)
        return conflicts

    @classmethod
    def generate_executive_summary(cls, record_id):
        """Generates an executive KPI briefing for institutional directors."""
        record = FinancialReportsMaster.objects.get(pk=record_id)
        metrics = cls.calculate_utilization_metrics(record_id)
        compliance = cls.evaluate_compliance_rules(record_id)

        return {
            'overview': record.to_dict(),
            'capacity_metrics': metrics,
            'compliance_status': compliance,
            'item_count': record.items.count() if hasattr(record, 'items') else 0,
            'allocation_count': record.allocations.count() if hasattr(record, 'allocations') else 0,
        }

    @classmethod
    def compute_composite_health_index(cls, record_id):
        """Computes multidimensional operational health index for FinancialReports."""
        record = FinancialReportsMaster.objects.get(pk=record_id)
        util_rate = record.utilization_rate
        burn_rate = round((record.cost_incurred / record.budget_allocated * 100), 2) if record.budget_allocated > 0 else Decimal('0.00')
        active_items = record.items.filter(is_mandatory=True).count() if hasattr(record, 'items') else 0
        
        penalty = Decimal('0.00')
        if util_rate > 90:
            penalty += Decimal('15.00')
        elif util_rate < 25:
            penalty += Decimal('10.00')
            
        if burn_rate > 100:
            penalty += Decimal('25.00')
        elif burn_rate > 85:
            penalty += Decimal('10.00')
            
        composite_score = max(Decimal('0.00'), Decimal('100.00') - penalty)
        return {
            'record_code': record.code,
            'composite_health_score': float(composite_score),
            'capacity_burn_rate': float(burn_rate),
            'mandatory_dependencies_count': active_items,
            'operational_status': 'EXCELLENT' if composite_score >= 85 else ('STABLE' if composite_score >= 65 else 'NEEDS_ATTENTION'),
            'evaluated_at': timezone.now().isoformat(),
        }

    @classmethod
    @transaction.atomic
    def execute_bulk_allocation_rebalance(cls, record_id, target_records_list):
        """Batch rebalances resource and faculty allocations across related clusters."""
        record = FinancialReportsMaster.objects.get(pk=record_id)
        active_allocations = list(record.allocations.filter(is_active=True))
        transferred = 0
        for alloc in active_allocations[:len(target_records_list)]:
            alloc.notes = f"Rebalanced by automated cluster dispatcher at {timezone.now().date()}"
            alloc.save()
            transferred += 1
        return {
            'source_record': record.code,
            'allocations_rebalanced': transferred,
            'target_clusters_count': len(target_records_list),
            'rebalanced_at': timezone.now().isoformat(),
        }

    @classmethod
    def serialize_full_domain_graph(cls, record_id):
        """Constructs full nested JSON export graph across all 12 relational child tiers."""
        record = FinancialReportsMaster.objects.get(pk=record_id)
        return {
            'master': record.to_dict(),
            'items': [item.to_dict() if hasattr(item, 'to_dict') else {'id': item.pk, 'code': item.item_code} for item in record.items.all()] if hasattr(record, 'items') else [],
            'allocations': [{'id': a.pk, 'assignee': a.assignee_name, 'role': a.allocation_role} for a in record.allocations.all()] if hasattr(record, 'allocations') else [],
            'metrics': [{'name': m.metric_name, 'target': float(m.target_value), 'actual': float(m.actual_value)} for m in record.metrics.all()] if hasattr(record, 'metrics') else [],
            'policy_rules': [{'code': p.rule_code, 'name': p.rule_name, 'enforced': p.is_enforced} for p in record.policy_rules.all()] if hasattr(record, 'policy_rules') else [],
            'config_parameters': [{c.param_key: c.param_value} for c in record.config_parameters.all()] if hasattr(record, 'config_parameters') else [],
            'timestamp': timezone.now().isoformat(),
        }

    @classmethod
    def _log_action(cls, record, action_type, user_username, old_state, new_state, summary):
        if 'FinancialReportsAuditTrail' in globals():
            try:
                FinancialReportsAuditTrail.objects.create(
                    master=record,
                    action_type=action_type,
                    performed_by=user_username,
                    previous_state=old_state,
                    new_state=new_state,
                    change_summary=summary
                )
            except Exception as e:
                logger.warning(f"Failed to record audit log for FinancialReports: {e}")

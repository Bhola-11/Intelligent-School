"""
Advanced Service Orchestration and Business Operations for EduFlow Expense Vouchers & Payment Approvals (Vouchers).
Includes event notifications, automated compliance reconciliation, batch state machines,
and enterprise analytics engines.
"""

import csv
import json
import logging
from decimal import Decimal
from django.db import transaction
from django.utils import timezone
from django.core.exceptions import ValidationError
from django.db.models import Q, Sum, Avg, Count, Min, Max

try:
    from .models import (
        VouchersMaster, VouchersItem, VouchersAllocation,
        VouchersMetricRecord, VouchersPolicyRule, VouchersSchedulePeriod,
        VouchersFeedbackReview, VouchersWorkflowTransition, VouchersAccessRule,
        VouchersConfigurationParameter, VouchersDocumentAttachment, VouchersAuditTrail
    )
except ImportError:
    try:
        from .models_vouchers import (
            VouchersMaster, VouchersItem, VouchersAllocation,
            VouchersMetricRecord, VouchersPolicyRule, VouchersSchedulePeriod,
            VouchersFeedbackReview, VouchersWorkflowTransition, VouchersAccessRule,
            VouchersConfigurationParameter, VouchersDocumentAttachment, VouchersAuditTrail
        )
    except ImportError:
        pass

logger = logging.getLogger(__name__)

class VouchersAdvancedService:
    """Enterprise-grade service orchestrator for complex operations in Vouchers."""

    @classmethod
    @transaction.atomic
    def bulk_create_records(cls, record_data_list, user_username="system"):
        """Batch ingestion of multiple master records with rollback safety."""
        created_records = []
        for data in record_data_list:
            code = data.pop('code', '').strip().upper()
            name = data.pop('name', '').strip()
            if not code or not name:
                continue
            rec = VouchersMaster.objects.create(
                code=code,
                name=name,
                created_by_user=user_username,
                updated_by_user=user_username,
                **data
            )
            created_records.append(rec)
            cls._record_audit_event(rec, "BULK_CREATE", user_username, f"Bulk created {code}")
        logger.info(f"Bulk created {len(created_records)} Vouchers records by {user_username}")
        return created_records

    @classmethod
    @transaction.atomic
    def execute_lifecycle_rollover(cls, from_academic_year, to_academic_year, user_username="system"):
        """Rolls over active configurations and master records to the next academic cycle."""
        active_records = VouchersMaster.objects.filter(status='ACTIVE', is_recurring=True)
        rollover_count = 0
        for rec in active_records:
            new_code = f"{rec.code}-{to_academic_year}"
            if not VouchersMaster.objects.filter(code=new_code).exists():
                cloned = VouchersMaster.objects.create(
                    code=new_code,
                    name=f"{rec.name} ({to_academic_year})",
                    category=rec.category,
                    tier=rec.tier,
                    scope=rec.scope,
                    priority=rec.priority,
                    status='DRAFT',
                    capacity=rec.capacity,
                    current_occupancy=0,
                    reserved_headroom=rec.reserved_headroom,
                    weightage=rec.weightage,
                    budget_allocated=rec.budget_allocated,
                    cost_incurred=Decimal('0.00'),
                    effective_start_date=timezone.now().date(),
                    is_recurring=True,
                    is_public=rec.is_public,
                    description=rec.description,
                    operational_guidelines=rec.operational_guidelines,
                    tags=rec.tags,
                    created_by_user=user_username,
                    updated_by_user=user_username
                )
                rollover_count += 1
                cls._record_audit_event(cloned, "ROLLOVER", user_username, f"Rolled over from {rec.code}")
        return {'status': 'completed', 'records_rolled_over': rollover_count}

    @classmethod
    def analyze_operational_efficiency(cls, record_id):
        """Deep analytics: capacity utilization, cost per capita, and risk scoring."""
        rec = VouchersMaster.objects.get(pk=record_id)
        util_rate = rec.utilization_rate
        cost_per_unit = (rec.cost_incurred / rec.current_occupancy) if rec.current_occupancy > 0 else Decimal('0.00')
        budget_burn_rate = round((rec.cost_incurred / rec.budget_allocated * 100), 2) if rec.budget_allocated > 0 else Decimal('0.00')
        
        # Risk assessment
        risk_flags = []
        if util_rate > 95:
            risk_flags.append("CRITICAL_CAPACITY_CONGESTION")
        elif util_rate < 30:
            risk_flags.append("UNDERUTILIZATION_WARNING")
            
        if budget_burn_rate > 100:
            risk_flags.append("BUDGET_OVERRUN_ALERT")
        elif budget_burn_rate > 85:
            risk_flags.append("BUDGET_EXHAUSTION_WARNING")

        return {
            'record_id': rec.pk,
            'code': rec.code,
            'name': rec.name,
            'utilization_rate': util_rate,
            'cost_per_occupant': float(cost_per_unit),
            'budget_burn_percentage': float(budget_burn_rate),
            'risk_level': 'HIGH' if len(risk_flags) >= 2 else ('MEDIUM' if len(risk_flags) == 1 else 'LOW'),
            'risk_flags': risk_flags,
            'evaluated_at': timezone.now().isoformat(),
        }

    @classmethod
    @transaction.atomic
    def process_schedule_conflict_resolution(cls, record_id, auto_resolve=False):
        """Detects and optionally resolves schedule overlaps across allocations."""
        record = VouchersMaster.objects.get(pk=record_id)
        active_allocations = list(record.allocations.filter(is_active=True).order_by('start_time'))
        conflicts = []
        
        for i in range(len(active_allocations)):
            for j in range(i + 1, len(active_allocations)):
                a1 = active_allocations[i]
                a2 = active_allocations[j]
                if a1.is_overlapping(a2.start_time, a2.end_time):
                    conflicts.append({
                        'allocation_1_id': a1.pk,
                        'assignee_1': a1.assignee_name,
                        'allocation_2_id': a2.pk,
                        'assignee_2': a2.assignee_name,
                        'conflict_window': f"{max(a1.start_time, a2.start_time)} to {min(a1.end_time or timezone.now(), a2.end_time or timezone.now())}"
                    })
                    if auto_resolve:
                        a2.is_active = False
                        a2.notes = f"Auto-deactivated due to scheduling conflict with allocation #{a1.pk}"
                        a2.save()
                        
        return {
            'conflict_count': len(conflicts),
            'conflicts': conflicts,
            'auto_resolved': auto_resolve
        }

    @classmethod
    def generate_annual_compliance_audit(cls, record_id):
        """Generates comprehensive regulatory audit report."""
        record = VouchersMaster.objects.get(pk=record_id)
        policy_checks = record.policy_rules.all()
        audit_history = record.audit_records.all().order_by('-timestamp')[:50]
        
        passed_rules = [r for r in policy_checks if r.check_compliance(record.utilization_rate)]
        failed_rules = [r for r in policy_checks if not r.check_compliance(record.utilization_rate)]
        
        compliance_pct = round((len(passed_rules) / len(policy_checks) * 100), 2) if policy_checks else 100.0
        
        return {
            'institution_record': record.code,
            'total_governance_rules': len(policy_checks),
            'passed_rules_count': len(passed_rules),
            'failed_rules_count': len(failed_rules),
            'compliance_score': compliance_pct,
            'audit_entry_count': len(audit_history),
            'status': 'COMPLIANT' if compliance_pct >= 90.0 else 'NON_COMPLIANT',
            'certified_at': timezone.now().isoformat(),
        }

    @classmethod
    def export_comprehensive_archive_dataset(cls, record_id):
        """Serializes the entire 12-model entity graph to an archive bundle."""
        record = VouchersMaster.objects.get(pk=record_id)
        return {
            'master': record.to_dict(),
            'items': [i.total_amount for i in record.items.all()] if hasattr(record, 'items') else [],
            'allocations': [a.assignee_name for a in record.allocations.all()] if hasattr(record, 'allocations') else [],
            'metrics': [m.metric_name for m in record.metrics.all()] if hasattr(record, 'metrics') else [],
            'policy_rules': [p.rule_code for p in record.policy_rules.all()] if hasattr(record, 'policy_rules') else [],
            'schedule_periods': [s.period_title for s in record.schedule_periods.all()] if hasattr(record, 'schedule_periods') else [],
            'reviews': [r.rating for r in record.reviews.all()] if hasattr(record, 'reviews') else [],
            'workflow_transitions': [w.to_stage for w in record.workflow_transitions.all()] if hasattr(record, 'workflow_transitions') else [],
            'access_rules': [ar.role_allowed for ar in record.access_rules.all()] if hasattr(record, 'access_rules') else [],
            'config_parameters': [{c.param_key: c.param_value} for c in record.config_parameters.all()] if hasattr(record, 'config_parameters') else [],
            'attachments': [att.title for att in record.attachments.all()] if hasattr(record, 'attachments') else [],
            'audit_trail_length': record.audit_records.count() if hasattr(record, 'audit_records') else 0,
        }

    @classmethod
    def calculate_utilization_index(cls, capacity, current_occupancy):
        """Calculates precise occupancy utilization ratio."""
        if not capacity or capacity <= 0:
            return Decimal('0.00')
        rate = (Decimal(str(current_occupancy)) / Decimal(str(capacity))) * Decimal('100.00')
        return round(rate, 2)

    @classmethod
    def evaluate_sla_health(cls, active_count, pending_count, threshold_ratio=0.85):
        """Evaluates SLA health score and breach status."""
        total = active_count + pending_count
        if total == 0:
            return {'status': 'OPTIMAL', 'health_ratio': 1.0, 'sla_breached': False}
        ratio = round(active_count / total, 4)
        is_breached = ratio < threshold_ratio
        return {
            'status': 'DEGRADED' if is_breached else 'HEALTHY',
            'health_ratio': ratio,
            'sla_breached': is_breached,
            'active_nodes': active_count,
            'pending_nodes': pending_count,
        }

    @classmethod
    def generate_cost_variance_matrix(cls, budget, actual_spent):
        """Generates cost burn rate and variance matrix."""
        budget_dec = Decimal(str(budget or 0))
        spent_dec = Decimal(str(actual_spent or 0))
        variance = budget_dec - spent_dec
        burn_rate = round((spent_dec / budget_dec * 100), 2) if budget_dec > 0 else Decimal('0.00')
        risk_tier = 'CRITICAL' if burn_rate > 100 else ('WARNING' if burn_rate > 85 else 'STABLE')
        return {
            'budget_allocated': float(budget_dec),
            'actual_spent': float(spent_dec),
            'variance_amount': float(variance),
            'burn_rate_percentage': float(burn_rate),
            'financial_risk_tier': risk_tier,
        }

    @classmethod
    def validate_lifecycle_transition(cls, current_status, target_status):
        """Validates allowable operational status transitions."""
        valid_transitions = {
            'DRAFT': ['PENDING_REVIEW', 'CANCELLED'],
            'PENDING_REVIEW': ['APPROVED', 'DRAFT', 'CANCELLED'],
            'APPROVED': ['ACTIVE', 'SUSPENDED'],
            'ACTIVE': ['IN_PROGRESS', 'SUSPENDED', 'COMPLETED'],
            'IN_PROGRESS': ['COMPLETED', 'SUSPENDED', 'ACTIVE'],
            'SUSPENDED': ['ACTIVE', 'CANCELLED', 'ARCHIVED'],
            'COMPLETED': ['ARCHIVED'],
            'CANCELLED': ['ARCHIVED'],
            'ARCHIVED': []
        }
        allowed = valid_transitions.get(current_status, [])
        if target_status not in allowed:
            raise ValidationError(f"Invalid state transition from {current_status} to {target_status}.")
        return True

    @classmethod
    def execute_workload_rebalancing(cls, source_record_id, target_record_id, units_to_transfer):
        """Transfers capacity allocations between operational nodes."""
        source = VouchersMaster.objects.get(pk=source_record_id)
        target = VouchersMaster.objects.get(pk=target_record_id)
        if source.current_occupancy < units_to_transfer:
            raise ValidationError("Source record has insufficient active units to transfer.")
        target_headroom = target.capacity - target.current_occupancy
        if target_headroom < units_to_transfer:
            raise ValidationError("Target record has insufficient available capacity headroom.")
        source.current_occupancy -= units_to_transfer
        target.current_occupancy += units_to_transfer
        source.save()
        target.save()
        return {
            'source_code': source.code,
            'source_new_occupancy': source.current_occupancy,
            'target_code': target.code,
            'target_new_occupancy': target.current_occupancy,
            'transferred_units': units_to_transfer,
        }

    @classmethod
    def build_telemetry_snapshot(cls, record_code, capacity, occupancy, budget, spent):
        """Creates operational telemetry metrics payload."""
        utilization = cls.calculate_utilization_index(capacity, occupancy)
        financials = cls.generate_cost_variance_matrix(budget, spent)
        return {
            'domain': 'Vouchers',
            'record_code': record_code,
            'utilization_rate': float(utilization),
            'financial_metrics': financials,
            'generated_at': timezone.now().isoformat(),
        }

    @classmethod
    def _record_audit_event(cls, record, action_type, user_username, summary):
        if 'VouchersAuditTrail' in globals():
            try:
                VouchersAuditTrail.objects.create(
                    master=record,
                    action_type=action_type,
                    performed_by=user_username,
                    change_summary=summary,
                    new_state=record.to_dict()
                )
            except Exception as e:
                logger.warning(f"Failed to record advanced audit log: {e}")

    @classmethod
    def evaluate_compliance_health_score(cls, threshold_score=80):
        """Calculates multi-dimensional operational compliance health score."""
        records = VouchersMaster.objects.all() if 'VouchersMaster' in globals() else []
        if not records:
            return {'compliance_score': 100.0, 'status': 'OPTIMAL', 'evaluated_records': 0}
        active = [r for r in records if r.status == 'ACTIVE']
        under_cap = [r for r in records if r.current_occupancy <= r.capacity]
        on_budget = [r for r in records if r.cost_incurred <= r.budget_allocated]
        score = (
            (len(active) / len(records) * 40.0) +
            (len(under_cap) / len(records) * 30.0) +
            (len(on_budget) / len(records) * 30.0)
        )
        return {
            'compliance_score': round(score, 2),
            'status': 'PASS' if score >= threshold_score else 'NEEDS_ATTENTION',
            'evaluated_records': len(records),
            'active_percentage': round((len(active) / len(records) * 100), 2),
            'capacity_compliance_percentage': round((len(under_cap) / len(records) * 100), 2),
            'budget_compliance_percentage': round((len(on_budget) / len(records) * 100), 2),
            'calculated_at': timezone.now().isoformat()
        }

    @classmethod
    def detect_operational_anomalies(cls):
        """Identifies statistical anomalies in occupancy, burn rate, and record states."""
        anomalies = []
        records = VouchersMaster.objects.all() if 'VouchersMaster' in globals() else []
        for r in records:
            if r.capacity > 0 and r.current_occupancy > (r.capacity * 1.10):
                anomalies.append({'code': r.code, 'type': 'OVER_CAPACITY_BREACH', 'severity': 'HIGH', 'occupancy': r.current_occupancy, 'capacity': r.capacity})
            if r.budget_allocated > 0 and r.cost_incurred > (r.budget_allocated * 1.15):
                anomalies.append({'code': r.code, 'type': 'BUDGET_OVERRUN_BREACH', 'severity': 'CRITICAL', 'cost': float(r.cost_incurred), 'budget': float(r.budget_allocated)})
            if r.status == 'SUSPENDED' and r.current_occupancy > 0:
                anomalies.append({'code': r.code, 'type': 'SUSPENDED_NODE_WITH_ACTIVE_LOAD', 'severity': 'MEDIUM', 'occupancy': r.current_occupancy})
        return {
            'anomaly_count': len(anomalies),
            'records_scanned': len(records),
            'has_critical_anomalies': any(a['severity'] == 'CRITICAL' for a in anomalies),
            'anomalies': anomalies,
            'detected_at': timezone.now().isoformat()
        }

    @classmethod
    def generate_executive_digest(cls):
        """Builds high-level summary digest for institutional leadership and board reviews."""
        records = VouchersMaster.objects.all() if 'VouchersMaster' in globals() else []
        total_budget = sum(r.budget_allocated for r in records)
        total_cost = sum(r.cost_incurred for r in records)
        total_cap = sum(r.capacity for r in records)
        total_occ = sum(r.current_occupancy for r in records)
        return {
            'domain': 'Vouchers',
            'total_registered_units': len(records),
            'total_budget_allocated': float(total_budget),
            'total_cost_incurred': float(total_cost),
            'net_financial_position': float(total_budget - total_cost),
            'total_capacity_available': total_cap,
            'total_capacity_utilized': total_occ,
            'aggregate_load_percentage': round((total_occ / total_cap * 100), 2) if total_cap > 0 else 0.0,
            'certified_digest_timestamp': timezone.now().isoformat()
        }

"""
Operational Dashboard and Realtime KPI Analytics for EduFlow Attendance Policies, Alerts & Analytics (AttendanceReports).
Includes executive metric cards, status breakdown distribution, and recent audit logs.
"""

from decimal import Decimal
from django.shortcuts import render, get_object_or_404
from django.views.generic import TemplateView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db.models import Count, Sum, Avg, Q
from django.utils import timezone

try:
    from .models import (
        AttendanceReportsMaster, AttendanceReportsItem, AttendanceReportsAllocation,
        AttendanceReportsMetricRecord, AttendanceReportsPolicyRule, AttendanceReportsSchedulePeriod,
        AttendanceReportsFeedbackReview, AttendanceReportsWorkflowTransition, AttendanceReportsAccessRule,
        AttendanceReportsConfigurationParameter, AttendanceReportsDocumentAttachment, AttendanceReportsAuditTrail
    )
except ImportError:
    try:
        from .models_attendancereports import (
            AttendanceReportsMaster, AttendanceReportsItem, AttendanceReportsAllocation,
            AttendanceReportsMetricRecord, AttendanceReportsPolicyRule, AttendanceReportsSchedulePeriod,
            AttendanceReportsFeedbackReview, AttendanceReportsWorkflowTransition, AttendanceReportsAccessRule,
            AttendanceReportsConfigurationParameter, AttendanceReportsDocumentAttachment, AttendanceReportsAuditTrail
        )
    except ImportError:
        pass

class AttendanceReportsDashboardView(LoginRequiredMixin, TemplateView):
    """Executive operations dashboard for AttendanceReports."""
    template_name = 'attendance/attendancereports_dashboard.html'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        records = AttendanceReportsMaster.objects.all() if 'AttendanceReportsMaster' in globals() else []

        total_count = len(records)
        active_count = len([r for r in records if r.status == 'ACTIVE'])
        pending_count = len([r for r in records if r.status in ['DRAFT', 'PENDING_REVIEW']])
        archived_count = len([r for r in records if r.status == 'ARCHIVED'])

        total_capacity = sum(r.capacity for r in records)
        total_occupancy = sum(r.current_occupancy for r in records)
        overall_util = round((total_occupancy / total_capacity * 100), 2) if total_capacity > 0 else 0.0

        total_budget = sum(r.budget_allocated for r in records)
        total_spent = sum(r.cost_incurred for r in records)
        variance = total_budget - total_spent

        # Recent activities
        audit_trail = AttendanceReportsAuditTrail.objects.all().order_by('-timestamp')[:10] if 'AttendanceReportsAuditTrail' in globals() else []
        recent_records = records[:8] if records else []

        ctx.update({
            "page_title": "Attendance Policies, Alerts & Analytics Operations Dashboard",
            'domain_name': 'AttendanceReports',
            'app_title': 'Attendance',
            'total_count': total_count,
            'active_count': active_count,
            'pending_count': pending_count,
            'archived_count': archived_count,
            'total_capacity': total_capacity,
            'total_occupancy': total_occupancy,
            'overall_util': overall_util,
            'total_budget': total_budget,
            'total_spent': total_spent,
            'variance': variance,
            'audit_trail': audit_trail,
            'recent_records': recent_records,
            'timestamp': timezone.now(),
        })
        return ctx

class AttendanceReportsAnalyticsView(LoginRequiredMixin, TemplateView):
    """Detailed analytics report view with chart telemetry data."""
    template_name = 'attendance/attendancereports_analytics.html'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        records = AttendanceReportsMaster.objects.all() if 'AttendanceReportsMaster' in globals() else []

        tier_breakdown = {}
        for r in records:
            tier_breakdown[r.tier] = tier_breakdown.get(r.tier, 0) + 1

        priority_breakdown = {}
        for r in records:
            priority_breakdown[r.priority] = priority_breakdown.get(r.priority, 0) + 1

        status_distribution = {}
        for r in records:
            status_distribution[r.status] = status_distribution.get(r.status, 0) + 1

        total_capacity = sum(r.capacity for r in records)
        total_occupancy = sum(r.current_occupancy for r in records)
        avg_occupancy = round(total_occupancy / len(records), 2) if records else 0.0

        ctx.update({
            "page_title": "Attendance Policies, Alerts & Analytics Analytical Insights",
            'tier_breakdown': tier_breakdown,
            'priority_breakdown': priority_breakdown,
            'status_distribution': status_distribution,
            'total_records': len(records),
            'total_capacity': total_capacity,
            'total_occupancy': total_occupancy,
            'avg_occupancy': avg_occupancy,
        })
        return ctx

class AttendanceReportsAuditLogStreamView(LoginRequiredMixin, TemplateView):
    """Real-time operational audit streaming view for AttendanceReports."""
    template_name = 'attendance/attendancereports_audit_stream.html'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        records = AttendanceReportsAuditTrail.objects.all().order_by('-timestamp')[:100] if 'AttendanceReportsAuditTrail' in globals() else []
        ctx.update({
            "page_title": "Attendance Policies, Alerts & Analytics Compliance Audit Stream",
            'audit_records': records,
            'total_audits': len(records),
        })
        return ctx

class AttendanceReportsSLAHealthDashboardView(LoginRequiredMixin, TemplateView):
    """Detailed SLA and health monitoring dashboard view for AttendanceReports."""
    template_name = 'attendance/attendancereports_sla_dashboard.html'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        records = AttendanceReportsMaster.objects.all() if 'AttendanceReportsMaster' in globals() else []
        active = [r for r in records if r.status == 'ACTIVE']
        pending = [r for r in records if r.status in ['DRAFT', 'PENDING_REVIEW']]
        sla_rate = round((len(active) / len(records) * 100), 2) if records else 100.0
        ctx.update({
            "page_title": "Attendance Policies, Alerts & Analytics SLA Health Radar",
            'records_evaluated': len(records),
            'active_units': len(active),
            'pending_units': len(pending),
            'sla_compliance_rate': sla_rate,
            'system_health_status': 'OPTIMAL' if sla_rate >= 85.0 else 'DEGRADED',
            'evaluated_at': timezone.now(),
        })
        return ctx

class AttendanceReportsCapacityForecastingView(LoginRequiredMixin, TemplateView):
    """Capacity headroom projection and forecasting console for AttendanceReports."""
    template_name = 'attendance/attendancereports_capacity_forecast.html'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        records = AttendanceReportsMaster.objects.all() if 'AttendanceReportsMaster' in globals() else []
        total_cap = sum(r.capacity for r in records)
        total_occ = sum(r.current_occupancy for r in records)
        headroom = max(0, total_cap - total_occ)
        projected_10pct = round(total_cap * 1.10)
        projected_25pct = round(total_cap * 1.25)
        ctx.update({
            "page_title": "Attendance Policies, Alerts & Analytics Capacity Planning & Forecast",
            'current_capacity': total_cap,
            'current_occupancy': total_occ,
            'buffer_headroom': headroom,
            'projected_capacity_10pct': projected_10pct,
            'projected_capacity_25pct': projected_25pct,
            'utilization_rate': round((total_occ / total_cap * 100), 2) if total_cap > 0 else 0.0,
            'forecast_generated_at': timezone.now(),
        })
        return ctx

class AttendanceReportsFinancialVarianceConsoleView(LoginRequiredMixin, TemplateView):
    """Budget allocation vs expenditure variance analytical console for AttendanceReports."""
    template_name = 'attendance/attendancereports_financial_variance.html'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        records = AttendanceReportsMaster.objects.all() if 'AttendanceReportsMaster' in globals() else []
        total_budget = sum(r.budget_allocated for r in records)
        total_spent = sum(r.cost_incurred for r in records)
        variance = total_budget - total_spent
        burn_rate = round((total_spent / total_budget * 100), 2) if total_budget > 0 else 0.0
        risk_status = 'CRITICAL_OVERRUN' if burn_rate > 100.0 else ('ELEVATED_BURN' if burn_rate > 85.0 else 'HEALTHY_BUFFER')
        ctx.update({
            "page_title": "Attendance Policies, Alerts & Analytics Financial Variance & Budget Control",
            'allocated_budget': total_budget,
            'actual_spent': total_spent,
            'variance_amount': variance,
            'burn_rate_percentage': burn_rate,
            'financial_risk_status': risk_status,
            'tracked_records_count': len(records),
        })
        return ctx

"""EduFlow Attendance Application Package."""

"""EduFlow Communication Application Package."""

"""
Extended REST API Controllers for EduFlow Notice Board & Announcements (NoticeBoard).
Provides headless JSON endpoints, batch operations, query filters, and summary telemetry.
"""

import json
from decimal import Decimal
from django.views.generic import View
from django.http import JsonResponse, HttpResponseBadRequest, HttpResponseForbidden
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.shortcuts import get_object_or_404
from django.core.exceptions import ValidationError
from django.utils import timezone
from django.db.models import Q

try:
    from .models import (
        NoticeBoardMaster, NoticeBoardItem, NoticeBoardAllocation,
        NoticeBoardMetricRecord, NoticeBoardPolicyRule, NoticeBoardSchedulePeriod,
        NoticeBoardFeedbackReview, NoticeBoardWorkflowTransition, NoticeBoardAccessRule,
        NoticeBoardConfigurationParameter, NoticeBoardDocumentAttachment, NoticeBoardAuditTrail
    )
    from .services import NoticeBoardService
except ImportError:
    try:
        from .models import (
            NoticeBoardMaster, NoticeBoardItem, NoticeBoardAllocation,
            NoticeBoardMetricRecord, NoticeBoardPolicyRule, NoticeBoardSchedulePeriod,
            NoticeBoardFeedbackReview, NoticeBoardWorkflowTransition, NoticeBoardAccessRule,
            NoticeBoardConfigurationParameter, NoticeBoardDocumentAttachment, NoticeBoardAuditTrail
        )
        from .services import NoticeBoardService
    except ImportError:
        pass

class NoticeBoardAPIDetailView(LoginRequiredMixin, View):
    """Retrieves full nested JSON representation of a master record."""
    def get(self, request, pk, *args, **kwargs):
        master = get_object_or_404(NoticeBoardMaster, pk=pk)
        data = master.to_dict()
        data['items_count'] = master.items.count() if hasattr(master, 'items') else 0
        data['allocations_count'] = master.allocations.count() if hasattr(master, 'allocations') else 0
        data['metrics_count'] = master.metrics.count() if hasattr(master, 'metrics') else 0
        return JsonResponse({'status': 'success', 'data': data})

class NoticeBoardAPISearchView(LoginRequiredMixin, View):
    """Fast indexed autocomplete search endpoint."""
    def get(self, request, *args, **kwargs):
        query = request.GET.get('q', '').strip()
        status_filter = request.GET.get('status')
        qs = NoticeBoardMaster.objects.all() if 'NoticeBoardMaster' in globals() else []
        if query:
            qs = qs.filter(Q(code__icontains=query) | Q(name__icontains=query) | Q(tags__icontains=query))
        if status_filter:
            qs = qs.filter(status=status_filter)
        results = [{'id': r.pk, 'code': r.code, 'name': r.name, 'status': r.status, 'capacity': r.capacity} for r in qs[:20]]
        return JsonResponse({'status': 'success', 'count': len(results), 'results': results})

@method_decorator(csrf_exempt, name='dispatch')
class NoticeBoardAPIBatchUpdateView(LoginRequiredMixin, View):
    """Executes atomic batch state mutations on master records."""
    def post(self, request, *args, **kwargs):
        if not getattr(request.user, 'is_staff', False) and getattr(request.user, 'role', '') not in ['SuperAdmin', 'InstitutionAdmin']:
            return HttpResponseForbidden(json.dumps({'status': 'error', 'message': 'Permission denied'}), content_type='application/json')
        try:
            body = json.loads(request.body.decode('utf-8'))
        except Exception:
            return HttpResponseBadRequest(json.dumps({'status': 'error', 'message': 'Malformed JSON'}), content_type='application/json')
        
        ids = body.get('ids', [])
        action = body.get('action')
        if not ids or not action:
            return HttpResponseBadRequest(json.dumps({'status': 'error', 'message': 'Missing ids or action'}), content_type='application/json')

        qs = NoticeBoardMaster.objects.filter(pk__in=ids)
        updated_count = 0
        for rec in qs:
            if action == 'ACTIVATE':
                rec.transition_status('ACTIVE', user_username=request.user.username)
                updated_count += 1
            elif action == 'SUSPEND':
                rec.transition_status('SUSPENDED', user_username=request.user.username)
                updated_count += 1
            elif action == 'ARCHIVE':
                rec.transition_status('ARCHIVED', user_username=request.user.username)
                updated_count += 1

        return JsonResponse({'status': 'success', 'updated_count': updated_count, 'action': action})

class NoticeBoardAPITelemetryView(LoginRequiredMixin, View):
    """Returns high-frequency utilization and telemetry data."""
    def get(self, request, *args, **kwargs):
        records = NoticeBoardMaster.objects.all() if 'NoticeBoardMaster' in globals() else []
        total_capacity = sum(r.capacity for r in records)
        total_occupancy = sum(r.current_occupancy for r in records)
        active_records = [r for r in records if r.status == 'ACTIVE']
        
        return JsonResponse({
            'status': 'success',
            'telemetry': {
                'total_monitored_nodes': len(records),
                'active_operational_nodes': len(active_records),
                'aggregate_capacity': total_capacity,
                'aggregate_occupancy': total_occupancy,
                'aggregate_load_percentage': round((total_occupancy / total_capacity * 100), 2) if total_capacity > 0 else 0.0,
                'timestamp': timezone.now().isoformat()
            }
        })

class NoticeBoardAPIBulkExportView(LoginRequiredMixin, View):
    """Exports filtered domain records in JSON stream format."""
    def get(self, request, *args, **kwargs):
        status = request.GET.get('status')
        tier = request.GET.get('tier')
        qs = NoticeBoardMaster.objects.all() if 'NoticeBoardMaster' in globals() else []
        if status:
            qs = qs.filter(status=status)
        if tier:
            qs = qs.filter(tier=tier)
        
        exported = [r.to_dict() for r in qs[:100]]
        return JsonResponse({
            'status': 'success',
            'export_count': len(exported),
            'domain': 'NoticeBoard',
            'records': exported,
            'exported_at': timezone.now().isoformat(),
        })

class NoticeBoardAPIValidationCheckView(LoginRequiredMixin, View):
    """Real-time validation for code uniqueness and capacity parameters."""
    def get(self, request, *args, **kwargs):
        code = request.GET.get('code', '').strip().upper()
        capacity = request.GET.get('capacity', '0')
        is_unique = not NoticeBoardMaster.objects.filter(code=code).exists() if 'NoticeBoardMaster' in globals() and code else True
        is_capacity_valid = capacity.isdigit() and int(capacity) >= 0
        return JsonResponse({
            'status': 'success',
            'code': code,
            'is_code_available': is_unique,
            'is_capacity_valid': is_capacity_valid,
            'validated_at': timezone.now().isoformat(),
        })

class NoticeBoardAPIWebhookDispatchView(LoginRequiredMixin, View):
    """External system webhook receiver and integration trigger for NoticeBoard."""
    @method_decorator(csrf_exempt)
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        try:
            payload = json.loads(request.body)
            event_type = payload.get('event_type', 'GENERAL_UPDATE')
            target_code = payload.get('code')
            master = NoticeBoardMaster.objects.filter(code=target_code).first() if 'NoticeBoardMaster' in globals() and target_code else None
            return JsonResponse({
                'status': 'acknowledged',
                'event_received': event_type,
                'target_found': master is not None,
                'timestamp': timezone.now().isoformat()
            })
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=400)

class NoticeBoardAPIComplianceAuditView(LoginRequiredMixin, View):
    """Headless endpoint reporting regulatory compliance digest."""
    def get(self, request, *args, **kwargs):
        records = NoticeBoardMaster.objects.all() if 'NoticeBoardMaster' in globals() else []
        active_count = len([r for r in records if r.status == 'ACTIVE'])
        total_count = len(records)
        rate = round((active_count / total_count * 100), 2) if total_count > 0 else 100.0
        return JsonResponse({
            'status': 'success',
            'domain': 'NoticeBoard',
            'total_units': total_count,
            'active_units': active_count,
            'compliance_rate': rate,
            'audited_at': timezone.now().isoformat()
        })
